BELAL Anais X BOUDELLAL Feth-Ellah

Veuillez noter que pour obtenir les statistics pour le TP8 , Lancez le fichier : MassTestTP8.py 

Pour le TP7, Pour obtenir les resultats pour Curiosity-test, Veuillez executer le fichier Run.py dans ./Test_TP07/Run.py 

Le resultat finale sera dans le fichier output.txt 


