#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h> 
#include "es_tableau.h"
#include "tri.h"

int est_trie(int tableau[], int taille) {
    for (int i = 0; i < taille - 1; i++) {
        if (tableau[i] > tableau[i + 1]) {
            return 0; // le tableau n'est pas trié
        }
    }
    return 1; // true 
}

void test_tri_insertion(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        FILE *input_file = fopen(argv[i], "r");
        if (input_file == NULL) {
            fprintf(stderr, "erreur de fichier %s.\n", argv[i]);
            continue; 
        }

        tableau_entiers t; 
        int taille = 0;

        while (fscanf(input_file, "%d", &t.tab[taille]) == 1) {
            taille++;
        }

        fclose(input_file);

        t.taille = taille;
        tri_insertion(&t);
        char nouveau_nom[256];
        strcpy(nouveau_nom, argv[i]);
        strcat(nouveau_nom, ".out");
        FILE *output_file = fopen(nouveau_nom, "w");
        if (output_file == NULL) {
            fprintf(stderr, "erreur de fichier %s.\n", nouveau_nom);
            continue; 
        }

        for (int j = 0; j < taille; j++) {
            fprintf(output_file, "%d\n", t.tab[j]);
        }

        fclose(output_file);

        if (est_trie(t.tab, taille) && t.taille == taille) {
            printf(" %s. Test avec success.\n", nouveau_nom);
        } else {
            printf("%s. Test avec echec.\n", nouveau_nom);
        }
    }
}


void test_tri_insertion_alea(int argc, char **argv) {
    if (argc != 3) {
        fprintf(stderr, "Utilisation : %s <nombre_de_tests> <taille_des_tests>\n", argv[0]);
        return;
    }

    int nombre_tests = atoi(argv[1]);
    int taille_tests = atoi(argv[2]);

    if (nombre_tests <= 0 || taille_tests <= 0) {
        fprintf(stderr, "Le nombre de tests et la taille des tests doivent être des entiers positifs.\n");
        return;
    }
    srand(time(NULL));

    for (int i = 0; i < nombre_tests; i++) {
        tableau_entiers t;
        t.taille = taille_tests;

        for (int j = 0; j < taille_tests; j++) {
            t.tab[j] = rand();
        }
        tri_insertion(&t);
        if (est_trie(t.tab, taille_tests)) {
            printf("Test %d réussi.\n", i + 1);
        } else {
            printf("Test %d échoué.\n", i + 1);
        }
    }
}