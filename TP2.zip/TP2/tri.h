#ifndef _TRI_H_
#define _TRI_H_

#include "type_tableau.h"

void tri_insertion(tableau_entiers *t);

#endif /* _TRI_H_ */
